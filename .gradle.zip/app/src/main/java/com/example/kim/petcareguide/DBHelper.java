package com.example.kim.petcareguide;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Kim on 9/27/2016.
 */
public class DBHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "MyDBName.db";
    public static final String CONTACTS_TABLE_NAME = "contacts";
    public static final String TABLE_DESCRIPTION = "description";
    public static final String CONTACTS_COLUMN_ID = "id";
    public static final String CONTACTS_COLUMN_PETNAME = "petname";
    public static final String CONTACTS_COLUMN_PETNO = "petno";
    public static final String CONTACTS_COLUMN_BIRTHDATE = "birthdate";
    public static final String CONTACTS_COLUMN_IMAGE = "image";
    public static final String DESCRIPTION_COLUMN= "description";


    public DBHelper(Context context) {

        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table contacts " + "(id integer primary key, petname text,petno text,birthdate date,image bitmap)");
        db.execSQL("create table description" + "(id integer primary key, description text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS contacts");
        db.execSQL("DROP TABLE IF EXISTS description");
        onCreate(db);
    }

    public boolean insertContact(String petname, String petno, String birthdate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("petname", petname);
        contentValues.put("petno", petno);
        contentValues.put("birthdate", birthdate);
        db.insert("contacts", null, contentValues);
        db.close();
        return true;

    }

    public boolean insertDescription(String description) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("description", description);
        db.insert("description", null, contentValues);
        db.close();
        return true;
    }


    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from contacts where contacts.id=" +id + "", null);
        return res;
    }

    public Cursor getDataDescription(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from description where id=" + id + "", null);
        return res;

    }

    public int numberOfRows() {
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, CONTACTS_TABLE_NAME);
        return numRows;
    }

    public int numberOfRow() {
        SQLiteDatabase db = this.getReadableDatabase();
        int numRow = (int) DatabaseUtils.queryNumEntries(db, TABLE_DESCRIPTION);
        return numRow;
    }

    public boolean updateContact(Integer id, String petname, String petno, String birthdate) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("petname", petname);
        contentValues.put("petno", petno);
        contentValues.put("birthdate", birthdate);

        db.update("contacts", contentValues, "id = ? ", new String[]{Integer.toString(id)});
        return true;
    }

    public boolean updateDescription(Integer id, String description) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("description", description);


        db.update("description", contentValues, "id = ? ", new String[]{Integer.toString(id)});
        return true;
    }

    public void deleteContact(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("contacts", "id = ? ", new String[]{Integer.toString(id)});
        db.close();
    }
    public void deleteDescription(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("description", "id = ? ", new String[]{Integer.toString(id)});
        db.close();
    }

    public ArrayList<String> getAllCotacts() {
        ArrayList<String> array_list = new ArrayList<String>();

        HashMap hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from contacts", null);
        res.moveToFirst();

        while (res.isAfterLast() == false) {
            array_list.add(res.getString(res.getColumnIndex(CONTACTS_COLUMN_PETNAME)));

            res.moveToNext();
        }
        return array_list;
    }

    public ArrayList<String> getAllDescription() {
        ArrayList<String> array_list = new ArrayList<String>();
        try {
        HashMap hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();

            Cursor res = db.rawQuery("select * from description", null);
            res.moveToFirst();

            while (res.isAfterLast() == false) {
                array_list.add(res.getString(res.getColumnIndex(DESCRIPTION_COLUMN)));
                res.moveToNext();

            }  } catch (SQLiteException e) {}
            return array_list;

        }



    }




