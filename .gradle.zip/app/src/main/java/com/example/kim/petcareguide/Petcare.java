package com.example.kim.petcareguide;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Petcare extends AppCompatActivity {

    private ImageView pet_info;
    DBHelper mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_petcare);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setLogo(R.drawable.pet_care);
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);



    }


    public void petinfo(View view)
    {

        Intent intent = new Intent(getApplicationContext(),Pet_Information.class);
        startActivity(intent);
        finish();
    }
    public void gtracker(View view)
    {
        Intent intent = new Intent(Petcare.this,Growth_Tracker.class);
        startActivity(intent);

    }
    public void reminder(View view)
    {
        Intent intent = new Intent(Petcare.this,Reminder.class);
        startActivity(intent);
    }
    public void callvet(View view)
    {
        Intent intent = new Intent(Petcare.this,Call_Vet.class);
        startActivity(intent);

    }


    public void home(View view)
    {
        Intent intent = new Intent(Petcare.this,Home.class);
        startActivity(intent);

    }
}
